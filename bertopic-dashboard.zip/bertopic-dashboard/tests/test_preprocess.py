from src.preprocess import clean_text


def test_clean_text():
    sample = "  Hello     world   "
    result = clean_text(sample)
    assert result == "Hello world"
