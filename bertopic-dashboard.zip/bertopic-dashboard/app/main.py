import os
import sys
from pathlib import Path

import streamlit as st

# Make `src` importable when running `streamlit run app/main.py`
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

from src.data_loader import load_csv, validate_columns
from src.preprocess import preprocess_dataframe
from src.utils import get_docs, get_timestamps
from src.topic_model import train_topic_model, get_topic_info_table
from src.trend_analysis import compute_topics_over_time, calculate_emerging_topics
from src.visualization import plot_topics_over_time, plot_hierarchy

st.set_page_config(page_title="BERTopic Dashboard", layout="wide")

st.title("BERTopic Emerging Topic Dashboard")
st.write(
    "Upload a CSV dataset to discover topics, analyze topic trends over time, "
    "and detect emerging topics."
)

uploaded_file = st.file_uploader("Upload CSV file", type=["csv"])

if uploaded_file is not None:
    df = load_csv(uploaded_file)

    st.subheader("Dataset Preview")
    st.dataframe(df.head())

    columns = df.columns.tolist()
    text_col = st.selectbox("Select text column", columns)
    time_col = st.selectbox("Select time column", columns)

    if st.button("Run Analysis"):
        try:
            validate_columns(df, text_col, time_col)

            with st.spinner("Preprocessing data..."):
                df = preprocess_dataframe(df, text_col, time_col)

            docs = get_docs(df, text_col)
            timestamps = get_timestamps(df, time_col)

            with st.spinner("Training BERTopic model..."):
                topic_model, topics, probs = train_topic_model(docs)

            with st.spinner("Generating topic summary..."):
                topic_info = get_topic_info_table(topic_model)

            with st.spinner("Analyzing topics over time..."):
                topics_over_time = compute_topics_over_time(topic_model, docs, timestamps)
                emerging = calculate_emerging_topics(topics_over_time, topic_model)

            st.subheader("Topic Summary")
            st.dataframe(topic_info)

            st.subheader("Emerging Topics")
            st.dataframe(emerging)

            st.subheader("Topics Over Time")
            fig1 = plot_topics_over_time(topic_model, topics_over_time)
            st.plotly_chart(fig1, use_container_width=True)

            st.subheader("Topic Hierarchy")
            fig2 = plot_hierarchy(topic_model, docs)
            st.plotly_chart(fig2, use_container_width=True)

        except Exception as e:
            st.error(f"An error occurred: {e}")
