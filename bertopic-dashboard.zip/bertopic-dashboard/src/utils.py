def get_docs(df, text_col):
    """Return the text documents as a list."""
    return df[text_col].tolist()


def get_timestamps(df, time_col):
    """Return timestamps as string dates for BERTopic."""
    return df[time_col].dt.date.astype(str).tolist()
