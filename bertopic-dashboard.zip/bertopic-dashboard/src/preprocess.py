import re
import pandas as pd


def clean_text(text):
    """Clean a single text entry by removing extra whitespace."""
    text = str(text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def preprocess_dataframe(df, text_col, time_col=None):
    """
    Preprocess the dataset:
    - Remove rows with missing text
    - Clean the text column
    - Convert time column to datetime if provided
    """
    df = df.copy()
    df = df.dropna(subset=[text_col])
    df[text_col] = df[text_col].apply(clean_text)

    if time_col is not None:
        df[time_col] = pd.to_datetime(df[time_col], errors="coerce")
        df = df.dropna(subset=[time_col])

    return df
