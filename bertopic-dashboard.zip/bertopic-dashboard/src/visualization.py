def plot_topics_over_time(topic_model, topics_over_time, top_n_topics=10):
    """Create a BERTopic visualization for topic trends over time."""
    return topic_model.visualize_topics_over_time(
        topics_over_time,
        top_n_topics=top_n_topics
    )


def plot_hierarchy(topic_model, docs):
    """Create a hierarchical topic visualization."""
    hierarchical_topics = topic_model.hierarchical_topics(docs)
    return topic_model.visualize_hierarchy(hierarchical_topics=hierarchical_topics)
