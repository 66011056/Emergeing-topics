# BERTopic Emerging Topic Dashboard

## Overview
This project applies BERTopic to a text dataset in order to discover hidden topics, analyze topic evolution over time, and detect emerging topics through an interactive Streamlit dashboard.

## Features
- Upload CSV datasets
- Topic modeling with BERTopic
- Topic summary table
- Topics-over-time analysis
- Emerging topic ranking
- Topic hierarchy visualization

## Recommended first dataset
Start with the Kaggle **News Category Dataset** (HuffPost headlines) because it includes time-based text data that works well for topic trends.

## Project Structure
- `app/` contains the Streamlit dashboard
- `src/` contains the main data science pipeline
- `data/` stores raw and processed datasets
- `outputs/` stores generated results
- `notebooks/` is used for experimentation

## Installation
```bash
pip install -r requirements.txt
```

## Run the app
```bash
streamlit run app/main.py
```

## Example CSV format
```csv
date,text
2024-01-10,"Large language models are improving code generation."
2024-02-15,"Diffusion models show strong results in image synthesis."
2024-03-20,"Retrieval-augmented generation improves factual accuracy."
2024-04-01,"Topic modeling can help analyze research trends."
```
